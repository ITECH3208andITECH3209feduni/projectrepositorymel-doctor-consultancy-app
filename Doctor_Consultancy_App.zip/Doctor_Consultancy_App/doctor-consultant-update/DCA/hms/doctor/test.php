<?php
session_start();
define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASS' ,'');
define('DB_NAME', 'phpzag_demo');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

$sqlInsert = "INSERT INTO chat(reciever_userid, sender_userid, message, status) VALUES ('".$_POST['to_user_id']."', '".$_SESSION['userid']."', '".$_POST['chat_message']."', '1')";
	// $result = mysqli_query($con, $sqlInsert);

	// $result = mysqli_query($con, $sqlInsert);
echo json_encode(['code'=>200, 'msg'=>$sqlInsert]);
	exit;
?>