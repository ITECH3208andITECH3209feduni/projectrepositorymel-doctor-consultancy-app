-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 17, 2021 at 06:19 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`, `profile_image`) VALUES
(1, 'admin', 'Test@12345', '28-12-2016 11:42:05 AM', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE IF NOT EXISTS `appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctorSpecialization` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `consultancyFees` int(11) DEFAULT NULL,
  `appointmentDate` varchar(255) DEFAULT NULL,
  `appointmentTime` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userStatus` int(11) DEFAULT NULL,
  `doctorStatus` int(11) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(3, 'Demo test', 7, 6, 600, '2019-06-29', '9:15 AM', '2019-06-23 18:31:28', 1, 0, '0000-00-00 00:00:00'),
(4, 'Ayurveda', 5, 5, 8050, '2019-11-08', '1:00 PM', '2019-11-05 10:28:54', 1, 1, '0000-00-00 00:00:00'),
(5, 'Dermatologist', 9, 7, 500, '2019-11-30', '5:30 PM', '2019-11-10 18:41:34', 1, 0, '2019-11-10 18:48:30'),
(6, 'Demo test', 7, 2, 200, '2021-06-25', '1:00 AM', '2021-06-15 19:17:16', 1, 1, NULL),
(7, 'General Physician', 3, 2, 1200, '2021-06-16', '1:00 AM', '2021-06-15 19:25:10', 1, 0, '2021-06-15 19:25:55'),
(8, 'Gynecologist/Obstetrician', 1, 1, 100, '2021-06-15', '10:00 PM', '2021-06-17 16:16:29', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE IF NOT EXISTS `chat` (
  `chatid` int(15) NOT NULL AUTO_INCREMENT,
  `sender_userid` int(15) NOT NULL,
  `reciever_userid` int(15) NOT NULL,
  `message` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`chatid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`chatid`, `sender_userid`, `reciever_userid`, `message`, `timestamp`, `status`) VALUES
(1, 1, 2, 'hi', '2021-06-17 01:31:11', 0),
(2, 2, 1, 'hii', '2021-06-17 01:37:10', 0),
(3, 2, 3, 'hii', '2021-06-17 01:37:52', 0),
(4, 3, 2, 'hello', '2021-06-17 01:38:04', 0),
(5, 3, 2, 'hiii', '2021-06-17 01:48:36', 0),
(6, 1, 2, 'what is name', '2021-06-17 01:49:07', 0),
(7, 3, 2, 'what is your name ?', '2021-06-17 02:06:25', 0),
(8, 2, 3, 'test-Doctor', '2021-06-17 02:06:52', 1),
(9, 3, 2, 'okay', '2021-06-17 02:10:37', 0),
(10, 2, 3, 'hello sir', '2021-06-17 16:12:07', 1),
(11, 2, 1, 'hello sir', '2021-06-17 16:12:21', 0),
(12, 1, 2, 'hello ', '2021-06-17 16:12:38', 0),
(13, 2, 1, 'how are you?', '2021-06-17 18:07:58', 0),
(14, 1, 2, 'fine', '2021-06-17 18:08:31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `chat_login_details`
--

DROP TABLE IF EXISTS `chat_login_details`;
CREATE TABLE IF NOT EXISTS `chat_login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `last_activity` timestamp NOT NULL,
  `is_typing` enum('no','yes') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `chat_users`
--

DROP TABLE IF EXISTS `chat_users`;
CREATE TABLE IF NOT EXISTS `chat_users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `current_session` int(11) NOT NULL DEFAULT '0',
  `online` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chat_users`
--

INSERT INTO `chat_users` (`userid`, `email`, `username`, `password`, `avatar`, `current_session`, `online`, `type`) VALUES
(1, 'test@gmail.com', 'test', 'cc03e747a6afbbcbf8be7668acfebee5', 'user1.jpg', 2, 1, 'Patient'),
(2, 'test1@gmail.com', 'test-Doctor', 'cc03e747a6afbbcbf8be7668acfebee5', 'user2.jpg', 3, 1, 'Doctor'),
(3, 'test3@gmail.com', 'test3', 'cc03e747a6afbbcbf8be7668acfebee5', 'user1.jpg', 2, 1, 'Patient');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
CREATE TABLE IF NOT EXISTS `doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext,
  `docFees` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `profile_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`, `profile_image`) VALUES
(1, 'Gynecologist/Obstetrician', 'test-Doctor', 'PRAJAPATI VAS GANESHPURA PALANPUR', '100', 7622818671, 'test1@gmail.com', 'cc03e747a6afbbcbf8be7668acfebee5', '2021-06-17 00:29:44', '2021-06-17 02:14:50', 'images/2nd.png');

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

DROP TABLE IF EXISTS `doctorslog`;
CREATE TABLE IF NOT EXISTS `doctorslog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(20, NULL, 'admin@klpolymersco.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:18:49', NULL, 0),
(21, 3, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:19:58', '16-06-2021 12:50:37 AM', 1),
(22, 3, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:23:03', '16-06-2021 12:53:28 AM', 1),
(23, 3, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:25:27', '16-06-2021 01:06:26 AM', 1),
(24, 3, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 15:30:05', '16-06-2021 09:04:30 PM', 1),
(25, 3, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 18:01:12', '16-06-2021 11:38:26 PM', 1),
(26, 3, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 18:20:00', '16-06-2021 11:56:43 PM', 1),
(27, 13, 'tete4@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 18:48:12', '17-06-2021 12:32:23 AM', 1),
(28, 17, 'tete4@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:02:34', '17-06-2021 12:47:57 AM', 1),
(29, 3, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 23:29:48', '17-06-2021 05:16:45 AM', 1),
(30, 1, 'test1@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 00:32:37', '17-06-2021 06:05:02 AM', 1),
(31, 1, 'test1@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 00:35:29', '17-06-2021 06:36:49 AM', 1),
(32, 1, 'test1@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 01:07:15', '17-06-2021 07:23:00 AM', 1),
(33, 1, 'test1@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 01:53:20', '17-06-2021 07:23:31 AM', 1),
(34, 1, 'test1@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 01:57:33', '17-06-2021 07:29:31 AM', 1),
(35, 1, 'test1@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 02:05:39', NULL, 1),
(36, NULL, 'test3@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 16:11:10', NULL, 0),
(37, 1, 'test1@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 16:11:49', '17-06-2021 11:39:52 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

DROP TABLE IF EXISTS `doctorspecilization`;
CREATE TABLE IF NOT EXISTS `doctorspecilization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(1, 'Gynecologist/Obstetrician', '2016-12-28 06:37:25', '0000-00-00 00:00:00'),
(2, 'General Physician', '2016-12-28 06:38:12', '0000-00-00 00:00:00'),
(3, 'Dermatologist', '2016-12-28 06:38:48', '0000-00-00 00:00:00'),
(4, 'Homeopath', '2016-12-28 06:39:26', '0000-00-00 00:00:00'),
(5, 'Ayurveda', '2016-12-28 06:39:51', '0000-00-00 00:00:00'),
(6, 'Dentist', '2016-12-28 06:40:08', '0000-00-00 00:00:00'),
(7, 'Ear-Nose-Throat (Ent) Specialist', '2016-12-28 06:41:18', '0000-00-00 00:00:00'),
(9, 'Demo test', '2016-12-28 07:37:39', '0000-00-00 00:00:00'),
(10, 'Bones Specialist demo', '2017-01-07 08:07:53', '0000-00-00 00:00:00'),
(11, 'Test', '2019-06-23 17:51:06', '2019-06-23 17:55:06'),
(12, 'Dermatologist', '2019-11-10 18:36:36', '2019-11-10 18:36:50');

-- --------------------------------------------------------

--
-- Table structure for table `master_user`
--

DROP TABLE IF EXISTS `master_user`;
CREATE TABLE IF NOT EXISTS `master_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='user_id';

--
-- Dumping data for table `master_user`
--

INSERT INTO `master_user` (`id`, `user_id`, `fullName`, `type`, `profile_image`) VALUES
(1, 17, 'test', 'Doctor', 'images/2nd.png'),
(2, 18, 'test', 'Doctor', NULL),
(9, 17, 'test123', 'Patient', 'images/2nd.png');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
CREATE TABLE IF NOT EXISTS `prescription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctorId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `cerate_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `doctorId`, `userId`, `description`, `cerate_date`) VALUES
(1, 1, 1, 'test', '2021-06-17 17:00:39'),
(2, 1, 1, 'test', '2021-06-17 18:01:59');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

DROP TABLE IF EXISTS `tblcontactus`;
CREATE TABLE IF NOT EXISTS `tblcontactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `AdminRemark` mediumtext,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `IsRead` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(1, 'test user', 'test@gmail.com', 2523523522523523, ' This is sample text for the test.', '2019-06-29 19:03:08', 'Test Admin Remark', '2019-06-30 12:55:23', 1),
(2, 'Anuj kumar', 'phpgurukulofficial@gmail.com', 1111111111111111, ' This is sample text for testing.  This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing.', '2019-06-30 13:06:50', NULL, NULL, NULL),
(3, 'fdsfsdf', 'fsdfsd@ghashhgs.com', 3264826346, 'sample text   sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  sample text  ', '2019-11-10 18:53:48', 'vfdsfgfd', '2019-11-10 18:54:04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalhistory`
--

DROP TABLE IF EXISTS `tblmedicalhistory`;
CREATE TABLE IF NOT EXISTS `tblmedicalhistory` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `PatientID` int(10) DEFAULT NULL,
  `BloodPressure` varchar(200) DEFAULT NULL,
  `BloodSugar` varchar(200) NOT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `Temperature` varchar(200) DEFAULT NULL,
  `MedicalPres` mediumtext,
  `CreationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmedicalhistory`
--

INSERT INTO `tblmedicalhistory` (`ID`, `PatientID`, `BloodPressure`, `BloodSugar`, `Weight`, `Temperature`, `MedicalPres`, `CreationDate`) VALUES
(2, 3, '120/185', '80/120', '85 Kg', '101 degree', '#Fever, #BP high\r\n1.Paracetamol\r\n2.jocib tab\r\n', '2019-11-06 04:20:07'),
(3, 2, '90/120', '92/190', '86 kg', '99 deg', '#Sugar High\r\n1.Petz 30', '2019-11-06 04:31:24'),
(4, 1, '125/200', '86/120', '56 kg', '98 deg', '# blood pressure is high\r\n1.koil cipla', '2019-11-06 04:52:42'),
(5, 1, '96/120', '98/120', '57 kg', '102 deg', '#Viral\r\n1.gjgjh-1Ml\r\n2.kjhuiy-2M', '2019-11-06 04:56:55'),
(6, 4, '90/120', '120', '56', '98 F', '#blood sugar high\r\n#Asthma problem', '2019-11-06 14:38:33'),
(7, 5, '80/120', '120', '85', '98.6', 'Rx\r\n\r\nAbc tab\r\nxyz Syrup', '2019-11-10 18:50:23');

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

DROP TABLE IF EXISTS `tblpatient`;
CREATE TABLE IF NOT EXISTS `tblpatient` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `Docid` int(10) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  `PatientContno` bigint(10) DEFAULT NULL,
  `PatientEmail` varchar(200) DEFAULT NULL,
  `PatientGender` varchar(50) DEFAULT NULL,
  `PatientAdd` mediumtext,
  `PatientAge` int(10) DEFAULT NULL,
  `PatientMedhis` mediumtext,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

DROP TABLE IF EXISTS `userlog`;
CREATE TABLE IF NOT EXISTS `userlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(24, NULL, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:14:20', NULL, 0),
(25, NULL, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:15:21', NULL, 0),
(26, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:16:05', '16-06-2021 12:48:06 AM', 1),
(27, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:23:41', '16-06-2021 12:55:16 AM', 1),
(28, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-15 19:37:22', '16-06-2021 01:10:49 AM', 1),
(29, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 15:25:42', '16-06-2021 08:59:49 PM', 1),
(30, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 17:07:00', '16-06-2021 11:30:20 PM', 1),
(31, NULL, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 18:18:57', NULL, 0),
(32, NULL, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 18:19:06', NULL, 0),
(33, NULL, 'nitesh@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 18:19:21', NULL, 0),
(34, NULL, 'tete5@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:31:34', NULL, 0),
(35, NULL, 'tete5@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:31:47', NULL, 0),
(36, NULL, 'tete5@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:32:32', NULL, 0),
(37, NULL, 'tete5@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:32:43', NULL, 0),
(38, NULL, 'tete5@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:33:24', NULL, 0),
(39, NULL, 'tete5@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:33:54', NULL, 0),
(40, NULL, 'tete5@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:34:08', NULL, 0),
(41, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:34:17', '17-06-2021 01:04:39 AM', 1),
(42, 17, 'test5@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-16 19:35:01', NULL, 1),
(43, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 00:00:20', NULL, 1),
(44, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 00:05:55', NULL, 1),
(45, 1, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 00:17:13', NULL, 1),
(46, 1, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 00:26:49', NULL, 1),
(47, 2, 'test3@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 01:36:48', NULL, 1),
(48, 1, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 01:38:43', NULL, 1),
(49, 2, 'test3@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 01:50:04', NULL, 1),
(50, 1, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 16:10:39', NULL, 1),
(51, 1, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2021-06-17 18:10:15', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `profile_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`, `profile_image`) VALUES
(1, 'test', 'PRAJAPATI VAS GANESHPURA PALANPUR', 'BK (Palanpur)', 'male', 'test@gmail.com', 'cc03e747a6afbbcbf8be7668acfebee5', '2021-06-17 00:16:12', '2021-06-17 01:35:31', 'images/2nd.png'),
(2, 'test3', 'PRAJAPATI VAS GANESHPURA PALANPUR', 'BK (Palanpur)', 'male', 'test3@gmail.com', 'cc03e747a6afbbcbf8be7668acfebee5', '2021-06-17 01:36:20', '2021-06-17 01:48:08', 'images/angular.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
